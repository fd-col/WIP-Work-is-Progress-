package it.wip.ui.fragments

import androidx.fragment.app.Fragment
import it.wip.R

class HeaderFragment : Fragment(R.layout.fragment_header)