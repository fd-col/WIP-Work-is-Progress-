class StoryDetailArguments {

  int storyId;
  String storyName;

  StoryDetailArguments({
    required this.storyId,
    required this.storyName
  });

}