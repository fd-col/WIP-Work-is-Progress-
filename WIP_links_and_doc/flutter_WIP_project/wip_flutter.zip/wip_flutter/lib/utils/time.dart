String twoDigits(int num) {
  return num.toString().padLeft(2, '0');
}